let score = 0;
let time = 30;
let timer = null;
let gameRunning = false;

const scoreDisplay = document.getElementById("score");
const timeDisplay = document.getElementById("time");
const message = document.getElementById("message");
const star = document.getElementById("star");
const gameArea = document.getElementById("gameArea");
const startButton = document.getElementById("startButton");

function moveStar() {
    const maxX = gameArea.clientWidth - star.offsetWidth;
    const maxY = gameArea.clientHeight - star.offsetHeight;

    const x = Math.max(0, Math.random() * maxX);
    const y = Math.max(0, Math.random() * maxY);

    star.style.left = x + "px";
    star.style.top = y + "px";
}

function endGame() {
    gameRunning = false;
    clearInterval(timer);
    timer = null;
    star.style.display = "none";
    message.textContent = "Time is up! Your final score is " + score + ".";
    startButton.disabled = false;
    startButton.textContent = "Play Again";
}

function startGame() {
    clearInterval(timer);

    score = 0;
    time = 30;
    gameRunning = true;

    scoreDisplay.textContent = score;
    timeDisplay.textContent = time;
    message.textContent = "";

    star.style.display = "block";
    startButton.disabled = true;
    startButton.textContent = "Game Running";

    moveStar();

    timer = setInterval(function() {
        time--;
        timeDisplay.textContent = time;

        if (time <= 0) {
            endGame();
        }
    }, 1000);
}

function catchStar() {
    if (!gameRunning) {
        return;
    }

    score++;
    scoreDisplay.textContent = score;
    moveStar();
}

startButton.addEventListener("click", startGame);
star.addEventListener("click", catchStar);
